# max-cut-experiments
Source code for 5 Max Cut algorithms implemented in Julia

All experiments can be run from the testing.jl file. The random graph, TSP graph, and Network Repository graph portions are separate and specific groups may be chosen by commenting/uncommmenting the appropriate sections. 

The random graphs we generated are in the Random Graphs folder. These were generated as we ran them, and thus our code does not currently read these files in. A small amount of code would need to be added to do that. The Network Repository graphs are in the files and files2 folders while the TSP graphs are read directly as a feature of Julia in the code. 

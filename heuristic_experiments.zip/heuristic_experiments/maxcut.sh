#! /bin/sh
julia "setup.jl"
julia "testing.jl"
